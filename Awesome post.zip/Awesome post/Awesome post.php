<?php
/**
 * Plugin Name:       Awesome post
 * Plugin URI:        https://www.linkedin.com/in/wpwebdev/
 * Description:       Custom Post type Awesome post plugin.
 * Version:           1.10.3
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Md. Nazrul Islam
 * Author URI:        https://www.linkedin.com/in/wpwebdev/
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       Custom Post type plugin
 * Domain Path:       n/a


/*
* Creating a function to create our CPT
*/
 
function custom_post_type() {
 
// Set UI labels for Custom Post Type
    $labels = array(
        'name'                => _x( 'Awesome post', 'Post Type General Name', 'twentytwenty' ),
        'singular_name'       => _x( 'Awesome post', 'Post Type Singular Name', 'twentytwenty' ),
        'menu_name'           => __( 'Awesome new posts', 'History', 'twentytwenty' ),
        'parent_item_colon'   => __( 'Parent Awesome post', 'twentytwenty' ),
        'all_items'           => __( 'All Awesome post', 'twentytwenty' ),
        'view_item'           => __( 'View Awesome post', 'twentytwenty' ),
        'add_new_item'        => __( 'Add New Awesome post', 'twentytwenty' ),
        'add_new'             => __( 'Add New', 'twentytwenty' ),
        'edit_item'           => __( 'Edit Awesome post', 'twentytwenty' ),
        'update_item'         => __( 'Update Awesome post', 'twentytwenty' ),
        'search_items'        => __( 'Search Awesome post', 'twentytwenty' ),
        'not_found'           => __( 'Not Found', 'twentytwenty' ),
        'not_found_in_trash'  => __( 'Not found in Trash', 'twentytwenty' ),
    );
     
// Set other options for Custom Post Type
     
    $args = array(
        'label'               => __( 'Awesome post', 'twentytwenty' ),
        'description'         => __( 'Awesome post news and reviews', 'twentytwenty' ),
        'labels'              => $labels,
        // Features this CPT supports in Post Editor
        'supports'            => array( 'title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields', ),
        // You can associate this CPT with a taxonomy or custom taxonomy. 
        'taxonomies'          => array( 'genres' ),
        /* A hierarchical CPT is like Pages and can have
        * Parent and child items. A non-hierarchical CPT
        * is like Posts.
        */ 
        'hierarchical'        => false,
        'public'              => true,
        'show_ui'             => true,
        'show_in_menu'        => true,
        'show_in_nav_menus'   => true,
        'show_in_admin_bar'   => true,
        'menu_position'       => 5,
        'can_export'          => true,
        'has_archive'         => true,
        'exclude_from_search' => false,
        'publicly_queryable'  => true,
        'capability_type'     => 'post',
        'show_in_rest' => true,
 
    );
     
    // Registering your Custom Post Type
    register_post_type( 'Awesome post', $args );
 
}
 
/* Hook into the 'init' action so that the function
* Containing our post type registration is not 
* unnecessarily executed. 
*/
 
add_action( 'init', 'custom_post_type', 0 );